Created by me, Founder

You can use all-most sandbox items in any gamemode

Discord: HNU Founder.lua#5046